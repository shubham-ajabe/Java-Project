DELETE FROM `courses`
DELETE FROM `enrolled_in`
DELETE FROM `instructors`
DELETE FROM `roles`
DELETE FROM `students`
DELETE FROM `users`
DELETE FROM `user_role`