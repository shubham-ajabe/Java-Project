package com.javacorner.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavacornerAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
